import SwiftUI

struct ContentView: View {
    @State var contentopened = false
    @State var contentopenedone = false
    @State var contentopenedtwo = false
    @State var contentopenedthree = false
    @State var contentopenedfour = false
    @State var contentopenedfive = false
    @State var opensike = false
    @State var openonesike = false
    @State var opentwosike = false
    @State var openthreesike = false
    @State var openfoursike = false
    
    var body: some View {
        VStack {
            Text("WARNING!")
                .foregroundColor(.red)
                .font(.title)
            Text("A sneaky imposter roams around, here are some suspects:")
                .foregroundColor(.blue)
            HStack {
                Text("Yellow:")
                    .foregroundColor(.yellow)
                    .font(.largeTitle)
                Image("YellowAmongUs")
                    .resizable()
                    .scaledToFit()
                Button(action: {
                    self.contentopened.toggle()
                }) {
                    Text("Toggle Desc Opened")
                        .foregroundColor(.brown)
                }
                
                if contentopened {
                    Text("How many times seen near dead bodies: 0, What it has to say: I swear it wasn't me! Go ask purple!")
                        .font(.caption)
                        .foregroundColor(.cyan)
                }
            }
            HStack {
                Text("Purple:")
                    .foregroundColor(.purple)
                    .font(.largeTitle)
                Image("PurpleAmongUs")
                    .resizable()
                    .scaledToFit()
                Button(action: {
                    self.contentopenedone.toggle()
                }) {
                    Text("Toggle Desc Opened")
                        .foregroundColor(.brown)
                }
                
                if contentopenedone {
                    Text("How many times seen near dead bodies: 1, What it has to say: Yellow is innocent, I think it's red.")
                        .font(.caption)
                        .foregroundColor(.cyan)
                }
            }
            HStack {
                Text("Green:")
                    .foregroundColor(.gray)
                    .font(.largeTitle)
                Image("GreenAmongUs")
                    .resizable()
                    .scaledToFit()
                Button(action: {
                    self.contentopenedtwo.toggle()
                }) {
                    Text("Toggle Desc Opened")
                        .foregroundColor(.brown)
                }
                
                if contentopenedtwo {
                    Text("How many times seen near dead bodies: 2, What it has to say: I agree with purple.")
                        .font(.caption)
                        .foregroundColor(.cyan)
                }
            }
            HStack {
                Text("Red:")
                    .foregroundColor(.red)
                    .font(.largeTitle)
                Image("RedAmongUs")
                    .resizable()
                    .scaledToFit()
                Button(action: {
                    self.contentopenedthree.toggle()
                }) {
                    Text("Toggle Desc Opened")
                        .foregroundColor(.brown)
                }
                
                if contentopenedthree {
                    Text("How many times seen near dead bodies: 0, What it has to say: Why me?!?")
                        .font(.caption)
                        .foregroundColor(.cyan)
                }
            }
            HStack {
                Text("Blue:")
                    .foregroundColor(.blue)
                    .font(.largeTitle)
                Image("BlueAmongUs")
                    .resizable()
                    .scaledToFit()
                Button(action: {
                    self.contentopenedfour.toggle()
                }) {
                    Text("Toggle Desc Opened")
                        .foregroundColor(.brown)
                }
                
                if contentopenedfour {
                    Text("How many times seen near dead bodies: 0, What it has to say: I'm speechless...")
                        .font(.caption)
                        .foregroundColor(.cyan)
                }
            }
            
            Text("Take a minute to decide who is the imposter, then, when you're ready, you can choose.")
                .font(.headline)
                .foregroundColor(.red)
            Button(action: {
                self.opensike.toggle()
            }) {
                Text("Yellow")
                    .foregroundColor(.yellow)
            }
            if opensike {
                Button(action: {
                    self.contentopenedfive.toggle()
                }) {
                    Text("Open!")
                        .foregroundColor(.blue)
                }
                if contentopenedfive {
                    Text("\nYellow was not the imposter because it was just acting innocent like he always does.")
                        .foregroundColor(.yellow)
                }
            }
            Button(action: {
                self.openonesike.toggle()
            }) {
                Text("Purple")
                    .foregroundColor(.purple)
            }
            if openonesike {
                Button(action: {
                    self.contentopenedfive.toggle()
                }) {
                    Text("Open!")
                        .foregroundColor(.blue)
                }
                if contentopenedfive {
                    Text("\nPurple was the imposter because it was just acting innocent like he always does.")
                        .foregroundColor(.purple)
                }
            }
            Button(action: {
                self.opentwosike.toggle()
            }) {
                Text("Yellow")
                    .foregroundColor(.yellow)
            }
            if opentwosike {
                Button(action: {
                    self.contentopenedfive.toggle()
                }) {
                    Text("Open!")
                        .foregroundColor(.blue)
                }
                if contentopenedfive {
                    Text("\nYellow was not the imposter because it was just acting innocent like he always does.")
                        .foregroundColor(.yellow)
                }
            }
            Button(action: {
                self.openthreesike.toggle()
            }) {
                Text("Yellow")
                    .foregroundColor(.yellow)
            }
            if openthreesike {
                Button(action: {
                    self.contentopenedfive.toggle()
                }) {
                    Text("Open!")
                        .foregroundColor(.blue)
                }
                if contentopenedfive {
                    Text("\nYellow was not the imposter because it was just acting innocent like he always does.")
                        .foregroundColor(.yellow)
                }
            }
            Button(action: {
                self.openfoursike.toggle()
            }) {
                Text("Yellow")
                    .foregroundColor(.yellow)
            }
            if openfoursike {
                Button(action: {
                    self.contentopenedfive.toggle()
                }) {
                    Text("Open!")
                        .foregroundColor(.blue)
                }
                if contentopenedfive {
                    Text("\nYellow was not the imposter because it was just acting innocent like he always does.")
                        .foregroundColor(.yellow)
                }
            }
        }
    }
}
