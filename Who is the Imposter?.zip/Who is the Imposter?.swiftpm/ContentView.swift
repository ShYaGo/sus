import SwiftUI
import AVFoundation
var player : AVAudioPlayer! 

struct ContentView: View {
    @State var contentopened = false
    @State var contentopenedone = false
    @State var contentopenedtwo = false
    @State var contentopenedthree = false
    @State var contentopenedfour = false
    @State var imposterchoose = ""
    
    var body: some View {
        VStack {
            Text("WARNING!")
                .foregroundColor(.red)
                .font(.title)
            Text("A sneaky imposter roams around, here are some suspects:")
                .foregroundColor(.blue)
            HStack {
                Text("Yellow:")
                    .foregroundColor(.yellow)
                    .font(.largeTitle)
                Image("YellowAmongUs")
                    .resizable()
                    .scaledToFit()
                Button(action: {
                    self.playSound(na: "Yellow")
                    self.contentopened.toggle()
                }) {
                    Text("Toggle Desc Opened")
                        .foregroundColor(.brown)
                }
                
                if contentopened {
                    Text("How many times seen near dead bodies: 0, What it has to say: I swear it wasn't me! Go ask purple!")
                        .foregroundColor(.cyan)
                }
            }
            HStack {
                Text("Purple:")
                    .foregroundColor(.purple)
                    .font(.largeTitle)
                Image("PurpleAmongUs")
                    .resizable()
                    .scaledToFit()
                Button(action: {
                    self.playSound(na: "Purple")
                    self.contentopenedone.toggle()
                }) {
                    Text("Toggle Desc Opened")
                        .foregroundColor(.brown)
                }
                
                if contentopenedone {
                    Text("How many times seen near dead bodies: 1, What it has to say: Yellow is innocent, I think it's red.")
                        .foregroundColor(.cyan)
                }
            }
            HStack {
                Text("Green:")
                    .foregroundColor(.gray)
                    .font(.largeTitle)
                Image("GreenAmongUs")
                    .resizable()
                    .scaledToFit()
                Button(action: {
                    self.playSound(na: "Green")
                    self.contentopenedtwo.toggle()
                }) {
                    Text("Toggle Desc Opened")
                        .foregroundColor(.brown)
                }
                
                if contentopenedtwo {
                    Text("How many times seen near dead bodies: 2, What it has to say: I agree with purple.")
                        .foregroundColor(.cyan)
                }
            }
            HStack {
                Text("Red:")
                    .foregroundColor(.red)
                    .font(.largeTitle)
                Image("RedAmongUs")
                    .resizable()
                    .scaledToFit()
                Button(action: {
                    self.playSound(na: "Red")
                    self.contentopenedthree.toggle()
                }) {
                    Text("Toggle Desc Opened")
                        .foregroundColor(.brown)
                }
                
                if contentopenedthree {
                    Text("How many times seen near dead bodies: 0, What it has to say: Why me?!?")
                        .foregroundColor(.cyan)
                }
            }
            HStack {
                Text("Blue:")
                    .foregroundColor(.blue)
                    .font(.largeTitle)
                Image("BlueAmongUs")
                    .resizable()
                    .scaledToFit()
                Button(action: {
                    self.playSound(na: "Blue")
                    self.contentopenedfour.toggle()
                }) {
                    Text("Toggle Desc Opened")
                        .foregroundColor(.brown)
                }
                
                if contentopenedfour {
                    Text("How many times seen near dead bodies: 0, What it has to say: I'm speechless...")
                        .foregroundColor(.cyan)
                }
            }
            
            Text("Take a minute to decide who is the imposter, then, when you're ready, type it in the small 'Type Here' box. (You can type Purple, Yellow, Red, Green, and Blue)")
                .font(.headline)
                .foregroundColor(.red)
            
            TextField("Type here", text: $imposterchoose)
                .multilineTextAlignment(.center)
                .foregroundColor(.red)
                .preferredColorScheme(.light)
            switch imposterchoose {
                case "Yellow":
                Text("Yellow was not the imposter because he was being the old inoccent thing he is.")
            case "Purple":
                Text("Purple was the imposter because it vented right after it killed red.")
            case "Green":
                Text("Green was not the imposter because, HELLO? I AM JUST NOT TRYING TO BE SUS!")
            case "Red":
                Text("Red was not the imposter because, ever heard the saying 'The most likely suspect is not the imposter?'")
            case "Blue":
                Text("Blue was not the imposter because he's straight up dumb.")
                default:
                Text("Invalid!")
            }
        }
    }
    func playSound(na: String) {
        let url = Bundle.main.url(forResource: na, withExtension: "mp3")
        guard url != nil else {
            return
        }
        
        do {
            player = try AVAudioPlayer(contentsOf: url!)
            player!.play()
        } catch {
            print("\(error)")
        }
    }
}
